package com.example.hehe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:flutter/material.dart';

class FavoriteScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          'Favorite Screen',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
